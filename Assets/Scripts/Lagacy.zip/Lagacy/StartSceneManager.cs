/*
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class StartSceneManager : MonoBehaviour
{
    public Button houseButton;
    public Button walkTodayButton;
    void Start()
    {
        houseButton.onClick.AddListener(GoHouseScene);
        walkTodayButton.onClick.AddListener(GoTimerScene);

    }

    void GoHouseScene()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene("HouseScene");
    }

    void GoTimerScene()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene("StopwatchScene");
    }

}
*/